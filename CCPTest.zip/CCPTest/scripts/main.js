//set API endpoint for Lambda function (API Gateway end point)
var updateAPI = "Put your API Gateway endpoint here. For example: https://i4p854l9be.execute-api.us-east-1.amazonaws.com/dev";


//Update records when someone clicks the Update button
function updateUser() {
    var newRecordingValue = $('#recordingButton').val();
	var inputData = {
		"agent_id": $('#agent_id').val(),
		"outbound_recording_enabled": $('#recordingButton').val()
	};

    //send new record to Lambda function
	$.ajax({
	   url: updateAPI,
	   type: 'POST',
	   data:  JSON.stringify(inputData)  ,
	   contentType: 'application/json; charset=utf-8',
	   success: function (response) {
           alert("Updated");
	   },
        
	   error: function () {
	       alert("error");
       }
        
    });
    if (newRecordingValue == "0"){
        document.getElementById("recordingButton").value = "1";
        document.getElementById("recording_value").value = "0";
        document.getElementById("recordingButton").innerHTML = "TURN RECORDING ON";
    };
    if (newRecordingValue == "1"){
        document.getElementById("recordingButton").value = "0";
        document.getElementById("recording_value").value = "1";
        document.getElementById("recordingButton").innerHTML = "TURN RECORDING OFF";
    };
    
};

function startupUser() {
	var inputData = {
		"agent_id": $('#agent_id').val(),
		"outbound_recording_enabled": "0"
	};

    //send new record to Lambda function
	$.ajax({
	   url: updateAPI,
	   type: 'POST',
	   data:  JSON.stringify(inputData)  ,
	   contentType: 'application/json; charset=utf-8',
	   success: function (response) {
           alert("Recording Function Updated");
           console.log(response);
	   },
        
	   error: function () {
	       alert("error");
           console.log(response);
       }
        
    });
    document.getElementById("recordingButton").value = "1";
    document.getElementById("recording_value").value = "0";
    document.getElementById("recordingButton").innerHTML = "TURN RECORDING ON";
};



document.getElementById("recordingButton").addEventListener("click", updateUser);
document.getElementById("initialize").addEventListener("click", startupUser);